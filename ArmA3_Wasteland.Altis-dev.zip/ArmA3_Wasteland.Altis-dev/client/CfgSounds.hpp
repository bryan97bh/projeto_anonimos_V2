// ******************************************************************************************
// * This project is licensed under the GNU Affero GPL v3. Copyright © 2019 A3Wasteland.com *
// ******************************************************************************************
//	@file Name: CfgSounds.hpp
//	@file Author: AgentRev

class MissileAlarm
{
	name = "MissileAlarm";
	sound[] = {"client\sounds\alarm_locked_by_missile_4x15.ogg", 0.25, 1};
	titles[] = {0,""};
};

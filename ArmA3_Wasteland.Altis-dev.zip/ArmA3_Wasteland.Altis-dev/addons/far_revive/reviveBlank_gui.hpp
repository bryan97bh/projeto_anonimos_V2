// ******************************************************************************************
// * This project is licensed under the GNU Affero GPL v3. Copyright © 2017 A3Wasteland.com *
// ******************************************************************************************
//	@file Name: reviveBlank_gui.hpp
//	@file Author: AgentRev

#include "gui_defines.hpp"

// To block input without showing anything
class ReviveBlankGUI
{
	idd = ReviveBlankGUI_IDD;
	movingEnabled = false;
};
